<?php

namespace App\Controller;

use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Encoder\XmlEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Form\Forms;
use Symfony\Component\Form\FormTypeInterface;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;

use App\Form\AdresseType;
use App\Form\DemandesMagasinType;
use App\Form\DemandesInternetType;

use App\Entity\Adresses;
use App\Entity\Clients;
use App\Entity\Enseignes;
use App\Entity\Demandes;
use App\Entity\Magasins;

use App\Services\Mailer;

/**
 * @Route("/demande-remboursement")
 */
class EnseigneController extends AbstractController
{
    /**
     * @Route("/", name="enseigne")
     */
    public function index(Request $request)
    {
        $encoders = [new XmlEncoder(), new JsonEncoder()];
        $normalizers = [new ObjectNormalizer()];

        $serializer = new Serializer($normalizers, $encoders);
        //On récupère les informations de la page d'accueil
        $post = $request->request->get('form');
        
        //On stocke les informations de la page d'accueil
        $session = $request->getSession();
        if($post != null){    
            
            $session->set('enseigne', $post['enseigne']);
            $session->set('date_achat', $post['date_achat']);
            $session->set('categorie', $post['categorie']);
            $session->set('prix', $post['prix']);
        }
        
        //On vérifie que le client est connecté
        if(!$this->isGranted('ROLE_USER')){
            return $this->redirectToRoute('connexion');
        }
        
        $user = $this->getUser();
        
        //On vérifie que le client a entré une enseigne valide
        $nom_enseigne = ucfirst($session->get('enseigne'));
        $repoEnseigne = $this->getDoctrine()->getRepository(Enseignes::class);
        $enseigne =  $repoEnseigne->findOneBy(['nomEnseigne' => $nom_enseigne]);
        
        $demande = new Demandes();
        $demande->setClient($user);

        $repoDemandes = $this->getDoctrine()->getRepository(Demandes::class);
        $demandes = $repoDemandes->findAll();
        $count = count($demandes);
        $demande->setNumeroDossier($count);
        $session->set('numDossier', $demande->getNumeroDossier());

        if($enseigne == null){
            return $this->render('enseigne/404_enseigne.html.twig');
        }

        $repoMagasins = $this->getDoctrine()->getRepository(Magasins::class);
        //$magasins = $repoMagasins->findBy(['enseigne' => $nom_enseigne]);
        $magasins = $repoMagasins->findByJustNom($nom_enseigne);
        $liste = $serializer->serialize($magasins, 'json');

        $formMagasin = $this->createForm(DemandesMagasinType::class, $demande,[
           'validation_groups' => array('User', 'inscription'),
        ]);
        $formMagasin->handleRequest($request); 
         
        $formInternet = $this->createForm(DemandesInternetType::class, $demande,[
            'validation_groups' => array('User', 'inscription'),
         ]);
        $formInternet->handleRequest($request); 
        
        $this->handle_form($user, $demande, $formMagasin, $session);
        $this->handle_form($user, $demande, $formInternet, $session);

        return $this->render('enseigne/index.html.twig', [
            'enseigne' => $enseigne,
            'post' => $post,
            'magasins' => $magasins,
            'form1' => $formMagasin->CreateView(), 
            'form2' => $formInternet->CreateView(), 
            'user' => $user,
        ]);
    }
    
    /**
     * @Route("/magasin", name="mag")
     */
    public function formMagasin(Request $request){
        $response = new Response();
        $user = $this->getUser();
        $demande = new Demandes();
        $demande->setClient($user);
        $formMagasin = $this->createForm(DemandesMagasinType::class, $demande,[
            'validation_groups' => array('User', 'inscription'),
        ]);
        $formMagasin->handleRequest($request);

        return $this->render('enseigne/magasin.html.twig', ['form1' => $formMagasin->CreateView(), 'user' => $user]);
    }


    /**
     * @Route("/internet", name="internet")
     */
    public function formInternet(Request $request){
        $response = new Response();
        $user = $this->getUser();
        $demande = new Demandes();
        $demande->setClient($user);
        $formInternet = $this->createForm(DemandesInternetType::class, $demande);
        $formInternet->handleRequest($request); 

        return $this->render('enseigne/internet.html.twig', ['form1' => $formInternet->CreateView(), 'user' => $user]);
    }

    public function handle_form($user, $demande, $form, $session){
        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            
            $demande->setPrixAchat($session->get('prix'));
            $dateAchat = \DateTime::createFromFormat('m-d-Y', $session->get('date_achat'));
            $demande->setCategorieProduit($session->get('categorie'));
            $demande->setEnseigne($session->get('enseigne'));
            $demande->setDateAchat($dateAchat);

            $em->persist($user);
            $em->persist($demande);
            $em->flush();

            return $this->redirectToRoute('profil');
        }
    }
}
