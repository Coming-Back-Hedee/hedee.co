<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Form\Forms;
use Symfony\Component\Form\Extension\Core\Type\MoneyType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Validator\Validator\ValidatorInterface;

use App\Entity\Categories;
use App\Entity\EligibiliteTest;

class AccueilController extends AbstractController
{
    /**
     * @Route("/", name="accueil")
     */
    public function index(Request $request)
    {
        $session = $request->getSession();
        $session->clear();

        $user = $this->getUser();
        $test = new EligibiliteTest();
        
        $form = $this->createFormBuilder($test, ['attr' => ['id' => 'form-eligibilite']])
            ->add('categorie', ChoiceType::class, [ 'choices' => [
                "Selectionnez votre categorie" => null,
                "Produits électroniques" => 'produits_electroniques',
                'Maisons et jardins' => 'maisons_et_jardins',
                'Jeux vidéos et jouets' => 'jvideos_et_jouets',
                "Santé et beauté" => 'sante_et_beaute',              
                'Auto et moto' => 'auto_et_moto',
                'Sports et mode' => "sports_et_mode"
            ],
            'label' => 'Catégorie du produit d\'achat'
            ])

            ->add('enseigne', TextType::class, ['label' => 'Enseigne d\'achat'])
            ->add('date_achat', TextType::class, ['label' => 'Date d\'achat'])       
            ->add('prix', MoneyType::class, ['label' => 'Prix de l\'article', 'currency' => false,])
            ->add('submit', SubmitType::class, ['label' => 'Vérifier sans frais'])
            
            //->setAction('/demande-remboursement/')
            ->getForm();

        $form->handleRequest($request); 
            if ($form->isSubmitted()){
                $test = $form->getData();
                    var_dump($test);
                if( $form->isValid()){
                var_dump("ok");
            }
            else{
                var_dump("oui");
            }
        }


        return $this->render('accueil/index.html.twig', [
            'form' => $form->CreateView(),
            'user' => $user,           
        ]);
    }

}
