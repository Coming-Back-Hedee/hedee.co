<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20190711121100 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE clients ADD adresse_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE clients ADD CONSTRAINT FK_C82E744DE7DC5C FOREIGN KEY (adresse_id) REFERENCES adresses (id)');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_C82E744DE7DC5C ON clients (adresse_id)');
        $this->addSql('ALTER TABLE demandes CHANGE facture facture VARCHAR(255) DEFAULT NULL, CHANGE statut statut VARCHAR(100) DEFAULT NULL');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE clients DROP FOREIGN KEY FK_C82E744DE7DC5C');
        $this->addSql('DROP INDEX UNIQ_C82E744DE7DC5C ON clients');
        $this->addSql('ALTER TABLE clients DROP adresse_id');
        $this->addSql('ALTER TABLE demandes CHANGE facture facture LONGTEXT DEFAULT NULL COLLATE utf8mb4_unicode_ci, CHANGE statut statut LONGTEXT DEFAULT NULL COLLATE utf8mb4_unicode_ci');
    }
}
