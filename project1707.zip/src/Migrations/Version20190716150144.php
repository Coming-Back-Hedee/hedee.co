<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20190716150144 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE enseignes ADD id INT AUTO_INCREMENT NOT NULL, DROP id_enseigne, ADD PRIMARY KEY (id)');
        $this->addSql('ALTER TABLE enseignes_categories ADD CONSTRAINT FK_587BEB31C01FD685 FOREIGN KEY (enseignes_id) REFERENCES enseignes (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE enseignes_categories ADD CONSTRAINT FK_587BEB31A21214B7 FOREIGN KEY (categories_id) REFERENCES categories (id) ON DELETE CASCADE');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE enseignes MODIFY id INT NOT NULL');
        $this->addSql('ALTER TABLE enseignes DROP PRIMARY KEY');
        $this->addSql('ALTER TABLE enseignes ADD id_enseigne INT NOT NULL, DROP id');
        $this->addSql('ALTER TABLE enseignes_categories DROP FOREIGN KEY FK_587BEB31C01FD685');
        $this->addSql('ALTER TABLE enseignes_categories DROP FOREIGN KEY FK_587BEB31A21214B7');
    }
}
