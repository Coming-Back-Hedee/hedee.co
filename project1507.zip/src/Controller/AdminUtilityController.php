<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\Session;

use App\Form\DemandesMagasinType;

use App\Entity\Demandes;
use App\Entity\Magasins;

use App\Repository\MagasinsRepository;

/**
 * @Route("/admin/utility")

 */
class AdminUtilityController extends AbstractController
{

    /**
     * @Route("/magasin", methods="GET", name="admin_utility_magasin")
     */
    public function getMagasinApi(Request $request, MagasinsRepository $magasinsRepository){

        $session = $request->getSession();
        //$nom_enseigne = $session->get('enseigne');
        $nom_enseigne = "auchan";
        $magasinsRepository = $this->getDoctrine()->getRepository(Magasins::class);
        $magasins = $magasinsRepository->findBy(['enseigne' => $nom_enseigne]);

        return $this->json([
            'magasins' => $magasins
        ], 200, [], []);
    }
}